# Politique de confidentialité — Pétanque Club (modèle à finaliser)

Pétanque Club enregistre localement sur l'appareil les profils de joueurs, équipes, scores et préférences nécessaires au fonctionnement du jeu. La caméra est utilisée uniquement lorsque l'utilisateur lance la fonction de mesure. L'application n'envoie pas volontairement les photos de mesure vers un serveur Pétanque Club.

La version financée par la publicité utilise Google AdMob. Selon les choix de consentement de l'utilisateur et les exigences applicables à sa région, Google et ses partenaires peuvent traiter des identifiants publicitaires, des informations sur l'appareil et des données nécessaires à la diffusion et à la mesure des annonces.

Avant publication, compléter ce texte avec l'identité et les coordonnées de l'éditeur, l'adresse de contact, l'URL publique finale, les durées de conservation éventuelles et la procédure d'exercice des droits.

---

# Privacy Policy — Pétanque Club (template to finalize)

Pétanque Club stores player profiles, teams, scores and preferences locally on the device for the operation of the game. Camera access is used only when the user starts the measurement feature. The app does not intentionally send measurement photos to a Pétanque Club server.

The ad-supported version uses Google AdMob. Depending on the user's consent choices and applicable regional requirements, Google and its partners may process advertising identifiers, device information and data needed for ad delivery and measurement.

Before publication, complete this text with the publisher identity and contact details, public policy URL, any retention periods and the process for exercising privacy rights.
