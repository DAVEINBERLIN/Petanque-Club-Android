# Pétanque Club — Android Store V1

Projet Android destiné à Google Play, construit autour du jeu Pétanque Club FR/EN.

## Configuration Android

- Application ID : `com.petanqueclub.app`
- Version : `1.0.0` (`versionCode 1`)
- `minSdk 24`
- `targetSdk 36`
- `compileSdk 36`
- Java 17
- Android Gradle Plugin 8.13.2 / Gradle 8.13
- Jeu FR/EN embarqué dans `app/src/main/assets/index.html`
- Contenu local servi par `WebViewAssetLoader` via `https://appassets.androidplatform.net`
- Caméra autorisée uniquement pour cette origine locale sécurisée
- Accès fichier `file://` désactivé
- HTTP non chiffré bloqué
- CSP conservée et recalculée après l'intégration Android

## AdMob + consentement

Le projet intègre :

- Google Mobile Ads SDK `25.4.0`
- Google UMP `4.0.0`
- bannière native uniquement quand l'utilisateur atteint la fin de la page
- interstitiel natif uniquement après « Bravo », quand l'utilisateur choisit Terminer ou Revanche
- bouton de choix de confidentialité lorsqu'UMP indique qu'il est requis

Pour les tests, le projet utilise uniquement les identifiants de TEST officiels de Google :

- App ID : `ca-app-pub-3940256099942544~3347511713`
- Bannière : `ca-app-pub-3940256099942544/9214589741`
- Interstitiel : `ca-app-pub-3940256099942544/1033173712`

Il ne faut pas remplacer ces IDs par de vraies pubs avant d'avoir créé l'application et les unités publicitaires dans votre propre compte AdMob.

## Générer le fichier Google Play

Google Play attend un Android App Bundle `.aab` pour une nouvelle application.

Dans Android Studio :

1. Ouvrir ce dossier comme projet Android.
2. Installer Android SDK Platform 36 si Android Studio le demande.
3. Synchroniser Gradle.
4. Tester la version debug sur un vrai téléphone.
5. `Build > Generate Signed Bundle / APK`.
6. Choisir `Android App Bundle`.
7. Créer ou sélectionner votre clé d'upload.
8. Générer le bundle release.
9. Le fichier final sera un `app-release.aab` à envoyer d'abord dans le canal **Test interne** de Play Console.

## Avant la publication publique

- Créer Pétanque Club dans AdMob.
- Remplacer l'App ID AdMob dans `AndroidManifest.xml`.
- Remplacer les IDs bannière/interstitiel dans `MainActivity.java`.
- Configurer le message européen dans AdMob > Privacy & messaging.
- Héberger une politique de confidentialité sur une URL HTTPS publique.
- Remplir la section Data safety dans Play Console.
- Ajouter l'icône Play Store 512×512, captures d'écran et visuel de présentation.
- Tester la caméra, les profils, scores, tournois, FR/EN, stockage local, pubs et fonctionnement hors ligne.
