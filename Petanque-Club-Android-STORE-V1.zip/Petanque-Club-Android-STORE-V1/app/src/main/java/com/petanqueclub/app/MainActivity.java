package com.petanqueclub.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA_PERMISSION = 1001;
    private static final int REQ_FILE_CHOOSER = 1002;

    // Official Google TEST ad unit IDs. Replace before Play Store publication.
    private static final String TEST_BANNER_ID = "ca-app-pub-3940256099942544/9214589741";
    private static final String TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";

    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebPermission;

    private LinearLayout adArea;
    private FrameLayout adViewContainer;
    private Button privacyOptionsButton;
    private AdView bannerAdView;
    private InterstitialAd interstitialAd;
    private String pendingPostGameAction;

    private ConsentInformation consentInformation;
    private final AtomicBoolean adsInitialized = new AtomicBoolean(false);
    private boolean pageRequestsBottomAd = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        adArea = findViewById(R.id.adArea);
        adViewContainer = findViewById(R.id.adViewContainer);
        privacyOptionsButton = findViewById(R.id.privacyOptionsButton);

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        configureWebView();
        configurePrivacyAndAds();
        privacyOptionsButton.setOnClickListener(v -> showPrivacyOptions());

        if (savedInstanceState == null) {
            webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSaveFormData(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);

        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        webView.addJavascriptInterface(new AndroidBridge(), "PetanqueAndroid");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (isLocalAppUri(uri)) return false;
                if ("https".equalsIgnoreCase(uri.getScheme())) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) {
                    }
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                Uri origin = request.getOrigin();
                boolean trustedOrigin = "https".equalsIgnoreCase(origin.getScheme())
                        && "appassets.androidplatform.net".equalsIgnoreCase(origin.getHost());
                boolean asksCamera = Arrays.asList(request.getResources())
                        .contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE);
                if (!trustedOrigin || !asksCamera) {
                    request.deny();
                    return;
                }
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                } else {
                    pendingWebPermission = request;
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA_PERMISSION);
                }
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingWebPermission == request) pendingWebPermission = null;
            }

            @Override
            public boolean onShowFileChooser(WebView view,
                                             ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                picker.addCategory(Intent.CATEGORY_OPENABLE);
                picker.setType("image/*");
                try {
                    startActivityForResult(picker, REQ_FILE_CHOOSER);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    return false;
                }
            }
        });
    }

    private boolean isLocalAppUri(Uri uri) {
        return uri != null
                && "https".equalsIgnoreCase(uri.getScheme())
                && "appassets.androidplatform.net".equalsIgnoreCase(uri.getHost());
    }

    private void configurePrivacyAndAds() {
        consentInformation = UserMessagingPlatform.getConsentInformation(this);
        ConsentRequestParameters params = new ConsentRequestParameters.Builder().build();

        consentInformation.requestConsentInfoUpdate(
                this,
                params,
                () -> UserMessagingPlatform.loadAndShowConsentFormIfRequired(this, formError -> {
                    updatePrivacyButton();
                    if (consentInformation.canRequestAds()) initializeAdsOnce();
                }),
                requestConsentError -> {
                    updatePrivacyButton();
                    if (consentInformation.canRequestAds()) initializeAdsOnce();
                });

        if (consentInformation.canRequestAds()) initializeAdsOnce();
    }

    private void updatePrivacyButton() {
        runOnUiThread(() -> {
            if (consentInformation == null) return;
            boolean required = consentInformation.getPrivacyOptionsRequirementStatus()
                    == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED;
            privacyOptionsButton.setVisibility(required ? View.VISIBLE : View.GONE);
        });
    }

    private void showPrivacyOptions() {
        UserMessagingPlatform.showPrivacyOptionsForm(this, formError -> updatePrivacyButton());
    }

    private void initializeAdsOnce() {
        if (!adsInitialized.compareAndSet(false, true)) return;
        new Thread(() -> MobileAds.initialize(this, status -> runOnUiThread(() -> {
            loadInterstitial();
            if (pageRequestsBottomAd) showBottomBanner();
        }))).start();
    }

    private void loadInterstitial() {
        InterstitialAd.load(
                this,
                TEST_INTERSTITIAL_ID,
                new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(InterstitialAd ad) {
                        interstitialAd = ad;
                        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {
                                interstitialAd = null;
                                continueAfterNativeAd();
                                loadInterstitial();
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(AdError adError) {
                                interstitialAd = null;
                                continueAfterNativeAd();
                                loadInterstitial();
                            }
                        });
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        interstitialAd = null;
                    }
                });
    }

    private void showPostGameInterstitial(String action) {
        pendingPostGameAction = action;
        if (!adsInitialized.get() || interstitialAd == null) {
            continueAfterNativeAd();
            if (adsInitialized.get()) loadInterstitial();
            return;
        }
        interstitialAd.show(this);
    }

    private void continueAfterNativeAd() {
        if (webView == null) return;
        pendingPostGameAction = null;
        webView.evaluateJavascript(
                "if(window.__petanqueNativeAdFinished){window.__petanqueNativeAdFinished();}",
                null);
    }

    private int getAdWidthDp() {
        float density = getResources().getDisplayMetrics().density;
        int widthPx = getResources().getDisplayMetrics().widthPixels;
        return Math.max(320, (int) (widthPx / density));
    }

    private void showBottomBanner() {
        pageRequestsBottomAd = true;
        updatePrivacyButton();
        if (!adsInitialized.get() || consentInformation == null || !consentInformation.canRequestAds()) {
            boolean privacyRequired = consentInformation != null
                    && consentInformation.getPrivacyOptionsRequirementStatus()
                    == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED;
            adViewContainer.setVisibility(View.GONE);
            adArea.setVisibility(privacyRequired ? View.VISIBLE : View.GONE);
            return;
        }
        adViewContainer.setVisibility(View.VISIBLE);
        if (bannerAdView == null) {
            bannerAdView = new AdView(this);
            bannerAdView.setAdUnitId(TEST_BANNER_ID);
            bannerAdView.setAdSize(AdSize.getInlineAdaptiveBannerAdSize(getAdWidthDp(), 120));
            adViewContainer.removeAllViews();
            adViewContainer.addView(bannerAdView);
            bannerAdView.loadAd(new AdRequest.Builder().build());
        }
        adArea.setVisibility(View.VISIBLE);
    }

    private void hideBottomBanner() {
        pageRequestsBottomAd = false;
        adArea.setVisibility(View.GONE);
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void showPostGameAd(String action) {
            runOnUiThread(() -> showPostGameInterstitial(action));
        }

        @JavascriptInterface
        public void setBottomAdVisible(boolean visible) {
            runOnUiThread(() -> {
                if (visible) showBottomBanner();
                else hideBottomBanner();
            });
        }

        @JavascriptInterface
        public void showPrivacyOptions() {
            runOnUiThread(MainActivity.this::showPrivacyOptions);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA_PERMISSION && pendingWebPermission != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pendingWebPermission.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            } else {
                pendingWebPermission.deny();
            }
            pendingWebPermission = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE_CHOOSER && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        if (bannerAdView != null) {
            bannerAdView.destroy();
            bannerAdView = null;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface("PetanqueAndroid");
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
